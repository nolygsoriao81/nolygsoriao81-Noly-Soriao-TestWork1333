import fog from '../../images/icons/fog-removebg-icon.png';
import nightClear from '../../images/icons/night_clear-removebg-icon.png';
import nigthCloudy from '../../images/icons/night_cloudy-removebg-icon.png';
import rainy from '../../images/icons/rainy-removebg-icon.png';
import snow from '../../images/icons/snow-removebg-icon.png';
import storm from '../../images/icons/storm-removebg-icon.png';
import sunnyCloud from '../../images/icons/sunny_cloudy-removebg-icon.png';
import sunny from '../../images/icons/sunny-removebg-icon.png';


// images/icons.js
export default {
  fog,
  nightClear,
  nigthCloudy,
  rainy,
  snow,
  storm,
  sunny,
    sunnyCloud
  };
  
  // Importing
 